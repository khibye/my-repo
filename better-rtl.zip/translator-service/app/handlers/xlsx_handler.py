"""
XLSX file handler.

Extracts translatable text from Excel workbooks (.xlsx/.xls),
filtering aggressively (skip numbers, dates, formulas, booleans).
Creates an Index sheet for sheet name translations instead of renaming
sheets (which would break cross-sheet formula references).
"""

import logging
from datetime import datetime
from io import BytesIO
from pathlib import Path

import openpyxl
from openpyxl.styles import Font

from app.handlers.base import BaseHandler
from app.utils.text_detection import is_translatable

logger = logging.getLogger(__name__)


class XlsxHandler(BaseHandler):
    def __init__(self, input_bytes: bytes):
        super().__init__(input_bytes)
        self._wb = None
        self._sheet_name_registry: list[str] = []
        self._has_charts = False
        self._has_pivot_tables = False

    def extract_texts(self) -> list[str]:
        """
        Parse the .xlsx file and extract all translatable cell values.

        Skips: None, empty, formulas (=...), pure numbers, dates,
        booleans, and strings that fail is_translatable().

        Also collects translatable sheet names for the Index sheet.

        Returns a deduplicated list of translatable strings.
        """
        self._wb = openpyxl.load_workbook(BytesIO(self.input_bytes))
        unique_set: set[str] = set()

        for ws in self._wb.worksheets:
            # Collect sheet name for the index
            if is_translatable(ws.title):
                self._sheet_name_registry.append(ws.title)
                unique_set.add(ws.title)

            # Detect charts, pivot tables, and macros (for warnings)
            if ws._charts:
                self._has_charts = True
            
            if hasattr(ws, "_pivots") and ws._pivots:
                self._has_pivot_tables = True

        if hasattr(self._wb, "vba_archive") and self._wb.vba_archive:
            logger.warning("XLSX: workbook contains VBA macros — they may not be preserved")

            for row in ws.iter_rows():
                for cell in row:
                    value = cell.value

                    # Skip non-translatable values
                    if value is None:
                        continue
                    if isinstance(value, bool):
                        continue
                    if isinstance(value, (int, float)):
                        continue
                    if isinstance(value, datetime):
                        continue
                    if not isinstance(value, str):
                        continue
                    if value.startswith("="):
                        continue
                    if not is_translatable(value):
                        continue

                    self._registry.append(
                        (ws.title, cell.row, cell.column, value)
                    )
                    unique_set.add(value)

        self._unique_texts = list(unique_set)
        logger.info(
            "XLSX: found %d unique strings across %d cell locations "
            "(+ %d sheet names)",
            len(self._unique_texts), len(self._registry),
            len(self._sheet_name_registry),
        )

        if self._has_charts:
            logger.warning(
                "XLSX: workbook contains charts — chart labels/titles "
                "may not be preserved correctly"
            )

        return self._unique_texts

    @property
    def warnings(self) -> list[str]:
        """Return any warnings about the workbook."""
        warns = []
        if self._has_charts:
            warns.append(
                "Workbook contains charts. Chart labels may not be "
                "translated or preserved correctly."
            )
        if self._has_pivot_tables:
            warns.append(
                "Workbook contains pivot tables. Pivot table data "
                "may not be preserved correctly."
            )
        return warns

    def write_translated(
        self, translations: dict[str, str], output_path: Path
    ) -> None:
        """
        Write translations back to the workbook.

        Step 1: Replace cell values with translations.
        Step 2: Create an Index sheet mapping original → translated sheet names
                (instead of renaming sheets, which breaks cross-sheet formulas).
        """
        if self._wb is None:
            raise RuntimeError(
                "extract_texts() must be called before write_translated()"
            )

        # Step 1: Write cell translations
        for sheet_name, row, col, original in self._registry:
            ws = self._wb[sheet_name]
            translated = translations.get(original, original)
            ws.cell(row=row, column=col).value = translated

        # Step 2: Create Index sheet with sheet name translations
        sheet_name_translations = {
            name: translations.get(name, name)
            for name in self._sheet_name_registry
            if translations.get(name, name) != name  # only include if actually translated
        }

        if sheet_name_translations:
            index_ws = self._wb.create_sheet("Index", 0)

            # Header row
            index_ws.cell(row=1, column=1, value="Original Sheet Name")
            index_ws.cell(row=1, column=2, value="Translated Sheet Name")

            # Style headers
            for col_idx in [1, 2]:
                cell = index_ws.cell(row=1, column=col_idx)
                cell.font = Font(bold=True)

            # Data rows
            for i, original_name in enumerate(self._sheet_name_registry):
                translated_name = translations.get(original_name, original_name)
                index_ws.cell(row=i + 2, column=1, value=original_name)
                index_ws.cell(row=i + 2, column=2, value=translated_name)

            # Column widths
            index_ws.column_dimensions["A"].width = 30
            index_ws.column_dimensions["B"].width = 30

            logger.info(
                "XLSX: created Index sheet with %d sheet name translations",
                len(sheet_name_translations),
            )

        self._wb.save(str(output_path))
        logger.info("XLSX: saved translated file to %s", output_path)

"""
Job tracking and temp file lifecycle.

Simple in-memory dict tracking jobs. For production at scale, swap for Redis.
"""

import logging
import os
import time
import uuid
from datetime import datetime
from pathlib import Path

from pydantic import BaseModel

from config import settings

logger = logging.getLogger(__name__)


class JobInfo(BaseModel):
    job_id: str
    filename: str
    status: str  # queued | processing | done | error
    created_at: datetime
    output_path: Path | None = None
    s3_output_key: str | None = None

    class Config:
        arbitrary_types_allowed = True


class JobManager:
    def __init__(self):
        self.jobs: dict[str, JobInfo] = {}

    def create_job(self, filename: str) -> str:
        """Create a new job and return its ID."""
        job_id = str(uuid.uuid4())
        self.jobs[job_id] = JobInfo(
            job_id=job_id,
            filename=filename,
            status="queued",
            created_at=datetime.utcnow(),
        )
        logger.info("Job created: %s for file %s", job_id, filename)
        return job_id

    def get_job(self, job_id: str) -> JobInfo | None:
        """Get job info by ID."""
        return self.jobs.get(job_id)

    def update_status(self, job_id: str, status: str):
        """Update job status."""
        job = self.jobs.get(job_id)
        if job:
            job.status = status

    def set_output(
        self, job_id: str, path: Path, s3_key: str = None
    ):
        """Set the output file path and optional S3 key."""
        job = self.jobs.get(job_id)
        if job:
            job.output_path = path
            job.s3_output_key = s3_key
            job.status = "done"
            logger.info(
                "Job %s complete: output at %s%s",
                job_id, path,
                f" (S3: {s3_key})" if s3_key else "",
            )

    def get_output(self, job_id: str) -> Path | None:
        """Get the output file path for a job."""
        job = self.jobs.get(job_id)
        if job:
            return job.output_path
        return None

    async def cleanup_expired(self):
        """
        Delete temp files older than TEMP_FILE_TTL_MINUTES
        and remove the corresponding job entries.
        """
        ttl_seconds = settings.temp_file_ttl_minutes * 60
        now = time.time()
        temp_dir = Path(settings.temp_dir)
        expired_jobs = []
        files_deleted = 0

        # Clean up job files
        for job_id, job in self.jobs.items():
            age_seconds = (datetime.utcnow() - job.created_at).total_seconds()
            if age_seconds > ttl_seconds:
                expired_jobs.append(job_id)
                if job.output_path and job.output_path.exists():
                    try:
                        job.output_path.unlink()
                        files_deleted += 1
                    except OSError as e:
                        logger.warning(
                            "Failed to delete expired file %s: %s",
                            job.output_path, e,
                        )

        # Remove expired job entries
        for job_id in expired_jobs:
            del self.jobs[job_id]

        # Also clean up any orphaned files in temp dir
        if temp_dir.exists():
            for entry in temp_dir.iterdir():
                if entry.name == ".gitkeep":
                    continue
                try:
                    file_age = now - entry.stat().st_mtime
                    if file_age > ttl_seconds:
                        if entry.is_file():
                            entry.unlink()
                            files_deleted += 1
                        elif entry.is_dir():
                            import shutil
                            shutil.rmtree(entry, ignore_errors=True)
                            files_deleted += 1
                except OSError:
                    pass

        if expired_jobs or files_deleted:
            logger.info(
                "Cleanup: removed %d expired jobs, %d files",
                len(expired_jobs), files_deleted,
            )


# Module-level singleton
job_manager = JobManager()

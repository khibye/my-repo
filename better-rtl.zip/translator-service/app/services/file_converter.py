"""
Legacy format conversion.

Converts .doc → .docx and .ppt → .pptx using LibreOffice headless.

LibreOffice is NOT thread-safe, so an asyncio.Lock ensures only
one conversion runs at a time.
"""

import asyncio
import logging
import os
import tempfile
from pathlib import Path

from config import settings

logger = logging.getLogger(__name__)

# Global lock — LibreOffice crashes with concurrent invocations
_libreoffice_lock = asyncio.Lock()

# Extension conversion map
_CONVERSION_MAP = {
    ".doc": ("docx", ".docx"),
    ".ppt": ("pptx", ".pptx"),
    ".xls": ("xlsx", ".xlsx"),
}


async def convert_legacy_format(
    input_bytes: bytes,
    from_ext: str,
) -> tuple[bytes, str]:
    """
    Convert a legacy format file to its modern equivalent using LibreOffice.

    Args:
        input_bytes: Raw file bytes
        from_ext: Source extension, e.g. ".doc", ".ppt", ".xls"

    Returns:
        (converted_bytes, new_extension) e.g. (bytes, ".docx")

    Raises:
        FileNotFoundError: LibreOffice binary not found
        RuntimeError: Conversion failed or timed out
    """
    from_ext = from_ext.lower()

    if from_ext not in _CONVERSION_MAP:
        raise ValueError(f"Unsupported legacy format: {from_ext}")

    target_format, new_ext = _CONVERSION_MAP[from_ext]

    # Verify LibreOffice exists
    if not os.path.isfile(settings.libreoffice_path):
        raise FileNotFoundError(
            f"LibreOffice not found at {settings.libreoffice_path}. "
            f"Install LibreOffice or update LIBREOFFICE_PATH in .env"
        )

    async with _libreoffice_lock:
        # Create a temp directory for this conversion
        with tempfile.TemporaryDirectory(prefix="translator_conv_") as tmpdir:
            # Write input file
            input_filename = f"input{from_ext}"
            input_path = Path(tmpdir) / input_filename
            input_path.write_bytes(input_bytes)

            logger.info(
                "Converting %s → %s via LibreOffice",
                from_ext, new_ext,
            )

            # Run LibreOffice
            cmd = [
                settings.libreoffice_path,
                "--headless",
                "--convert-to", target_format,
                "--outdir", tmpdir,
                str(input_path),
            ]

            try:
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )

                try:
                    stdout, stderr = await asyncio.wait_for(
                        process.communicate(),
                        timeout=60.0,
                    )
                except asyncio.TimeoutError:
                    process.kill()
                    await process.wait()
                    raise RuntimeError(
                        f"LibreOffice conversion timed out after 60 seconds "
                        f"(converting {from_ext} → {new_ext})"
                    )

                if process.returncode != 0:
                    stderr_text = stderr.decode("utf-8", errors="replace")
                    raise RuntimeError(
                        f"LibreOffice conversion failed (exit code {process.returncode}): "
                        f"{stderr_text}"
                    )

            except FileNotFoundError:
                raise FileNotFoundError(
                    f"Could not execute LibreOffice at {settings.libreoffice_path}"
                )

            # Find the output file
            output_filename = f"input{new_ext}"
            output_path = Path(tmpdir) / output_filename

            if not output_path.exists():
                # Try to find any file with the target extension
                candidates = list(Path(tmpdir).glob(f"*{new_ext}"))
                if candidates:
                    output_path = candidates[0]
                else:
                    raise RuntimeError(
                        f"LibreOffice conversion produced no output file "
                        f"(expected {output_filename} in {tmpdir})"
                    )

            output_bytes = output_path.read_bytes()
            logger.info(
                "Conversion complete: %s → %s (%d bytes → %d bytes)",
                from_ext, new_ext, len(input_bytes), len(output_bytes),
            )

            return output_bytes, new_ext

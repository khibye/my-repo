"""
Tests for app.utils.json_parser.parse_json_response()
"""

import pytest
from app.utils.json_parser import parse_json_response


class TestParseJsonResponse:
    """Tests for the JSON response parser."""

    def test_valid_json(self):
        raw = '{"0": "Bonjour", "1": "le monde"}'
        result = parse_json_response(raw)
        assert result == {"0": "Bonjour", "1": "le monde"}

    def test_json_with_markdown_fences(self):
        raw = '```json\n{"0": "Bonjour", "1": "le monde"}\n```'
        result = parse_json_response(raw)
        assert result == {"0": "Bonjour", "1": "le monde"}

    def test_json_with_plain_fences(self):
        raw = '```\n{"0": "Bonjour"}\n```'
        result = parse_json_response(raw)
        assert result == {"0": "Bonjour"}

    def test_json_with_surrounding_text(self):
        raw = 'Here is the translation:\n{"0": "Bonjour"}\nHope that helps!'
        result = parse_json_response(raw)
        assert result == {"0": "Bonjour"}

    def test_json_with_trailing_comma(self):
        raw = '{"0": "Bonjour", "1": "le monde",}'
        result = parse_json_response(raw)
        assert result == {"0": "Bonjour", "1": "le monde"}

    def test_empty_string(self):
        assert parse_json_response("") is None

    def test_none_input(self):
        assert parse_json_response(None) is None

    def test_whitespace_only(self):
        assert parse_json_response("   ") is None

    def test_pure_text_no_json(self):
        assert parse_json_response("This is not JSON at all") is None

    def test_json_array_returns_none(self):
        """Should return None because we expect a dict, not a list."""
        assert parse_json_response('["hello", "world"]') is None

    def test_nested_json(self):
        raw = '{"0": "Bonjour", "nested": {"a": "b"}}'
        result = parse_json_response(raw)
        assert result is not None
        assert result["0"] == "Bonjour"

    def test_unicode_content(self):
        raw = '{"0": "你好世界", "1": "مرحبا"}'
        result = parse_json_response(raw)
        assert result is not None
        assert result["0"] == "你好世界"
        assert result["1"] == "مرحبا"

    def test_escaped_quotes(self):
        raw = '{"0": "He said \\"hello\\""}'
        result = parse_json_response(raw)
        assert result is not None
        assert result["0"] == 'He said "hello"'

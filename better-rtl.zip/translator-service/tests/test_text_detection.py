"""
Tests for app.utils.text_detection.is_translatable()
"""

import pytest
from app.utils.text_detection import is_translatable


class TestIsTranslatable:
    """Tests for the is_translatable function."""

    # --- Should return False ---

    def test_none(self):
        assert is_translatable(None) is False

    def test_empty_string(self):
        assert is_translatable("") is False

    def test_whitespace_only(self):
        assert is_translatable("   ") is False
        assert is_translatable("\t\n") is False

    def test_single_character(self):
        assert is_translatable("A") is False
        assert is_translatable("1") is False
        assert is_translatable("-") is False

    def test_pure_numbers(self):
        assert is_translatable("12345") is False
        assert is_translatable("3.14") is False
        assert is_translatable("1,000.50") is False
        assert is_translatable("$42.50") is False
        assert is_translatable("-99") is False

    def test_dates(self):
        assert is_translatable("2024-01-15") is False
        assert is_translatable("15/01/2024") is False
        assert is_translatable("01.15.2024") is False

    def test_times(self):
        assert is_translatable("14:30") is False
        assert is_translatable("2:30 PM") is False
        assert is_translatable("14:30:00") is False

    def test_hex_hashes(self):
        assert is_translatable("a1b2c3d4e5f6") is False
        assert is_translatable("DEADBEEF") is False

    def test_uuids(self):
        assert is_translatable("550e8400-e29b-41d4-a716-446655440000") is False

    def test_emails(self):
        assert is_translatable("user@example.com") is False

    def test_urls(self):
        assert is_translatable("https://example.com/page") is False
        assert is_translatable("http://www.google.com") is False

    def test_file_paths(self):
        assert is_translatable("/usr/bin/python") is False
        assert is_translatable("C:\\Users\\test") is False

    def test_pure_symbols(self):
        assert is_translatable("---") is False
        assert is_translatable("***") is False
        assert is_translatable("===") is False

    def test_non_string_types(self):
        assert is_translatable(42) is False
        assert is_translatable(3.14) is False
        assert is_translatable(True) is False

    # --- Should return True ---

    def test_english_text(self):
        assert is_translatable("Hello world") is True

    def test_mixed_content(self):
        assert is_translatable("Total: $42.50") is True
        assert is_translatable("Item #3 description") is True

    def test_sentence(self):
        assert is_translatable("This is a complete sentence.") is True

    def test_cyrillic(self):
        assert is_translatable("Привет мир") is True

    def test_arabic(self):
        assert is_translatable("مرحبا بالعالم") is True

    def test_chinese(self):
        assert is_translatable("你好世界") is True

    def test_japanese(self):
        assert is_translatable("こんにちは世界") is True

    def test_korean(self):
        assert is_translatable("안녕하세요 세계") is True

    def test_devanagari(self):
        assert is_translatable("नमस्ते दुनिया") is True

    def test_short_words(self):
        assert is_translatable("OK") is True
        assert is_translatable("Yes") is True
        assert is_translatable("No") is True

    def test_column_headers(self):
        assert is_translatable("Product Name") is True
        assert is_translatable("Total Revenue") is True

"""
PPTX file handler.

Extracts translatable text from PowerPoint presentations (.pptx)
preserving run-level formatting across slides, tables, groups, and notes.
"""

import logging
from io import BytesIO
from pathlib import Path

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

from app.handlers.base import BaseHandler
from app.utils.text_detection import is_translatable

logger = logging.getLogger(__name__)


class PptxHandler(BaseHandler):
    def __init__(self, input_bytes: bytes):
        super().__init__(input_bytes)
        self._prs: Presentation | None = None

    def extract_texts(self) -> list[str]:
        """
        Parse the .pptx file and extract all translatable text.

        Scans:
        1. Text frames (titles, body text, text boxes) → runs
        2. Tables in slides → cells → text frames → runs
        3. Grouped shapes (recursive)
        4. Slide notes

        Returns a deduplicated list of translatable strings.
        """
        self._prs = Presentation(BytesIO(self.input_bytes))
        unique_set: set[str] = set()

        for slide_idx, slide in enumerate(self._prs.slides):
            # Process all shapes on the slide
            self._process_shapes(slide.shapes, unique_set, slide_idx)

            # 4. Slide notes
            if slide.has_notes_slide:
                notes_frame = slide.notes_slide.notes_text_frame
                if notes_frame:
                    for para in notes_frame.paragraphs:
                        self._extract_runs(para, unique_set, slide_idx, "notes")

        self._unique_texts = list(unique_set)
        logger.info(
            "PPTX: found %d unique strings across %d locations",
            len(self._unique_texts), len(self._registry),
        )
        return self._unique_texts

    def _process_shapes(self, shapes, unique_set: set[str], slide_idx: int):
        """Process a collection of shapes, handling groups recursively."""
        for shape in shapes:
            # 1. Text frames
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    self._extract_runs(para, unique_set, slide_idx, "text_frame")

            # 2. Tables
            if shape.has_table:
                for row in shape.table.rows:
                    for cell in row.cells:
                        if cell.text_frame:
                            for para in cell.text_frame.paragraphs:
                                self._extract_runs(
                                    para, unique_set, slide_idx, "table"
                                )

            # 3. Groups — recurse
            if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                self._process_shapes(shape.shapes, unique_set, slide_idx)

    def _extract_runs(
        self,
        paragraph,
        unique_set: set[str],
        slide_idx: int,
        source: str,
    ):
        """Extract text from runs in a paragraph."""
        for run in paragraph.runs:
            text = run.text
            if text and text.strip() and is_translatable(text.strip()):
                self._registry.append(("run", run, text, slide_idx, source))
                unique_set.add(text.strip())

    def write_translated(
        self, translations: dict[str, str], output_path: Path
    ) -> None:
        """
        Write translations back to the presentation.

        Sets run.text = translated for each registry entry, preserving
        font, size, color, and other formatting attributes.
        """
        if self._prs is None:
            raise RuntimeError(
                "extract_texts() must be called before write_translated()"
            )

        for entry in self._registry:
            run = entry[1]
            original_text = entry[2]
            translated = translations.get(original_text.strip(), original_text)
            run.text = translated

        self._prs.save(str(output_path))
        logger.info("PPTX: saved translated file to %s", output_path)

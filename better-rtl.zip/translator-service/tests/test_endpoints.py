"""
Tests for API endpoints.

Uses FastAPI's TestClient for synchronous endpoint testing.
"""

import io
import json

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def client():
    """Create a test client."""
    from main import app
    return TestClient(app)


class TestHealthEndpoint:
    def test_health_check(self, client):
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"


class TestSupportedFormats:
    def test_get_supported_formats(self, client):
        response = client.get("/api/supported-formats")
        assert response.status_code == 200
        formats = response.json()
        assert ".docx" in formats
        assert ".pdf" in formats
        assert ".csv" in formats
        assert ".xlsx" in formats
        assert ".pptx" in formats


class TestTranslateEndpoint:
    def test_unsupported_format(self, client):
        """Test that unsupported formats are rejected."""
        file_content = b"test content"
        response = client.post(
            "/api/translate",
            files={"file": ("test.txt", io.BytesIO(file_content), "text/plain")},
            data={"target_lang": "French"},
        )
        assert response.status_code == 400

    def test_missing_target_lang(self, client):
        """Test that missing target_lang returns 422."""
        from docx import Document

        doc = Document()
        doc.add_paragraph("Hello")
        buf = io.BytesIO()
        doc.save(buf)
        buf.seek(0)

        response = client.post(
            "/api/translate",
            files={"file": ("test.docx", buf, "application/octet-stream")},
        )
        assert response.status_code == 422


class TestDownloadEndpoint:
    def test_nonexistent_file(self, client):
        """Test download of nonexistent file returns 404."""
        response = client.get("/api/download/nonexistent.docx")
        assert response.status_code == 404

    def test_path_traversal_prevention(self, client):
        """Test that path traversal is blocked."""
        response = client.get("/api/download/../../etc/passwd")
        assert response.status_code == 404

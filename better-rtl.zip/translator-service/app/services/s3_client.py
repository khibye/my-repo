"""
S3 client for file downloads and uploads.

Handles downloading source files from S3 and optionally uploading
translated results back. Uses aioboto3 for async operations.
All files come from the same bucket (settings.s3_bucket_name).
"""

import logging
from urllib.parse import urlparse

import aioboto3

from config import settings

logger = logging.getLogger(__name__)


class S3Client:
    def __init__(self):
        self.session = aioboto3.Session()

    def _get_client_kwargs(self) -> dict:
        """Build the kwargs for the S3 client constructor."""
        kwargs = {
            "aws_access_key_id": settings.s3_access_key_id,
            "aws_secret_access_key": settings.s3_secret_access_key,
            "region_name": settings.s3_region,
        }
        if settings.s3_endpoint_url:
            kwargs["endpoint_url"] = settings.s3_endpoint_url
        return kwargs

    async def download(self, s3_key: str) -> tuple[bytes, str]:
        """
        Download a file from S3.

        Args:
            s3_key: The object key, e.g. "uploads/report.docx"
                    OR a full URL like "https://bucket.s3.amazonaws.com/uploads/report.docx"
                    If a full URL is provided, parse out the key portion.

        Returns:
            (file_bytes, filename) — filename is the last segment of the key.

        Raises:
            FileNotFoundError if the key doesn't exist.
            ValueError if the key is empty or malformed.
        """
        # Parse URL if needed
        key = self.parse_s3_url(s3_key)

        if not key:
            raise ValueError("S3 key is empty or malformed")

        filename = key.split("/")[-1]
        if not filename:
            raise ValueError(f"Could not extract filename from S3 key: {key}")

        logger.info("S3: downloading s3://%s/%s", settings.s3_bucket_name, key)

        try:
            async with self.session.client("s3", **self._get_client_kwargs()) as client:
                response = await client.get_object(
                    Bucket=settings.s3_bucket_name,
                    Key=key,
                )
                file_bytes = await response["Body"].read()
                logger.info(
                    "S3: downloaded %s (%d bytes)",
                    filename, len(file_bytes),
                )
                return file_bytes, filename
        except client.exceptions.NoSuchKey:
            raise FileNotFoundError(
                f"S3 object not found: s3://{settings.s3_bucket_name}/{key}"
            )
        except Exception as e:
            if "NoSuchKey" in str(type(e).__name__) or "Not Found" in str(e):
                raise FileNotFoundError(
                    f"S3 object not found: s3://{settings.s3_bucket_name}/{key}"
                )
            raise

    async def upload(
        self,
        file_bytes: bytes,
        s3_key: str,
        content_type: str = None,
    ) -> str:
        """
        Upload translated file back to S3.

        The destination key is: settings.s3_translated_prefix + original_key
        e.g. "translated/uploads/report.docx"

        Returns the full destination key.
        """
        dest_key = f"{settings.s3_translated_prefix}{s3_key}"

        logger.info(
            "S3: uploading to s3://%s/%s (%d bytes)",
            settings.s3_bucket_name, dest_key, len(file_bytes),
        )

        put_kwargs = {
            "Bucket": settings.s3_bucket_name,
            "Key": dest_key,
            "Body": file_bytes,
        }
        if content_type:
            put_kwargs["ContentType"] = content_type

        async with self.session.client("s3", **self._get_client_kwargs()) as client:
            await client.put_object(**put_kwargs)

        logger.info("S3: uploaded successfully to %s", dest_key)
        return dest_key

    @staticmethod
    def parse_s3_url(url_or_key: str) -> str:
        """
        If given a full S3 URL, extract the object key.

        Handles these URL formats:
          - https://bucket.s3.amazonaws.com/path/to/file.docx
          - https://s3.region.amazonaws.com/bucket/path/to/file.docx
          - s3://bucket/path/to/file.docx
          - path/to/file.docx  (already a key, return as-is)
        """
        url_or_key = url_or_key.strip()

        if not url_or_key:
            return ""

        # s3:// protocol
        if url_or_key.startswith("s3://"):
            parts = url_or_key[5:].split("/", 1)
            return parts[1] if len(parts) > 1 else ""

        # HTTP(S) URLs
        if url_or_key.startswith(("http://", "https://")):
            parsed = urlparse(url_or_key)
            host = parsed.hostname or ""
            path = parsed.path.lstrip("/")

            # Format: bucket.s3.amazonaws.com/key
            if ".s3." in host or host.endswith(".s3.amazonaws.com"):
                return path

            # Format: s3.region.amazonaws.com/bucket/key
            if host.startswith("s3.") and ".amazonaws.com" in host:
                # First path segment is bucket, rest is key
                parts = path.split("/", 1)
                return parts[1] if len(parts) > 1 else ""

            # Generic: just use the path
            return path

        # Already a key
        return url_or_key

    async def validate_connection(self) -> bool:
        """
        Test S3 connectivity. Called on startup.
        Does a HeadBucket call. Returns True if successful, False otherwise.
        """
        if not settings.s3_bucket_name:
            logger.info("S3: no bucket configured, skipping validation")
            return False

        try:
            async with self.session.client("s3", **self._get_client_kwargs()) as client:
                await client.head_bucket(Bucket=settings.s3_bucket_name)
            logger.info(
                "S3: connection validated for bucket '%s'",
                settings.s3_bucket_name,
            )
            return True
        except Exception as e:
            logger.warning("S3: connection validation failed: %s", str(e))
            return False


# Module-level singleton
s3_client = S3Client()

"""
Tests for app.engine.translator.translate_batch()

These tests mock the LLM client to test translation logic
without requiring an actual LLM connection.
"""

import json
from unittest.mock import AsyncMock, patch

import pytest

from app.engine.translator import translate_batch


@pytest.mark.asyncio
async def test_translate_batch_success():
    """Test successful batch translation."""
    texts = ["Hello world", "Good morning"]

    mock_response = json.dumps({
        "0": "Bonjour le monde",
        "1": "Bonjour",
    })

    with patch("app.engine.translator.llm_client") as mock_llm:
        mock_llm.complete = AsyncMock(return_value=mock_response)
        result = await translate_batch(texts, "French")

    assert result["Hello world"] == "Bonjour le monde"
    assert result["Good morning"] == "Bonjour"


@pytest.mark.asyncio
async def test_translate_batch_empty():
    """Test with empty input."""
    result = await translate_batch([], "French")
    assert result == {}


@pytest.mark.asyncio
async def test_translate_batch_llm_returns_markdown():
    """Test when LLM wraps response in markdown fences."""
    texts = ["Hello"]

    mock_response = '```json\n{"0": "Bonjour"}\n```'

    with patch("app.engine.translator.llm_client") as mock_llm:
        mock_llm.complete = AsyncMock(return_value=mock_response)
        result = await translate_batch(texts, "French")

    assert result["Hello"] == "Bonjour"


@pytest.mark.asyncio
async def test_translate_batch_retries_on_bad_json():
    """Test that bad JSON triggers retries."""
    texts = ["Hello"]

    mock_responses = [
        "This is not JSON",  # attempt 1
        "Still not JSON",    # attempt 2
        '{"0": "Bonjour"}',  # attempt 3
    ]

    with patch("app.engine.translator.llm_client") as mock_llm:
        mock_llm.complete = AsyncMock(side_effect=mock_responses)
        result = await translate_batch(texts, "French", max_retries=3)

    assert result["Hello"] == "Bonjour"


@pytest.mark.asyncio
async def test_translate_batch_all_retries_fail_single_string():
    """Test that total failure returns original text."""
    texts = ["Hello"]

    with patch("app.engine.translator.llm_client") as mock_llm:
        mock_llm.complete = AsyncMock(return_value="garbage")
        result = await translate_batch(texts, "French", max_retries=1)

    # Should fall back to original
    assert result["Hello"] == "Hello"


@pytest.mark.asyncio
async def test_translate_batch_validates_response_keys():
    """Test response validation — missing keys cause retry."""
    texts = ["Hello", "World", "Test"]

    mock_responses = [
        # Only has 1/3 keys — below 80% threshold
        '{"0": "Bonjour"}',
        # Has 3/3 keys — passes validation
        '{"0": "Bonjour", "1": "Monde", "2": "Test"}',
    ]

    with patch("app.engine.translator.llm_client") as mock_llm:
        mock_llm.complete = AsyncMock(side_effect=mock_responses)
        result = await translate_batch(texts, "French", max_retries=2)

    assert result["Hello"] == "Bonjour"
    assert result["World"] == "Monde"

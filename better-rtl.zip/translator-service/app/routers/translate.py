"""
Single file translation router.

Handles direct file upload and S3-based translation, plus file download.
Routers are THIN — they validate input, call the orchestrator, and stream results.
"""

import logging
import os
import uuid
from pathlib import Path

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, StreamingResponse

from config import settings
from app.models.schemas import S3TranslateRequest
from app.services import orchestrator
from app.services.s3_client import s3_client
from app.services.job_manager import job_manager

logger = logging.getLogger(__name__)

router = APIRouter()

SUPPORTED_EXTENSIONS = {
    ".docx", ".doc", ".pptx", ".ppt",
    ".xlsx", ".xls", ".csv", ".pdf",
}

# Content type mapping
CONTENT_TYPE_MAP = {
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".doc": "application/msword",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".ppt": "application/vnd.ms-powerpoint",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".xls": "application/vnd.ms-excel",
    ".csv": "text/csv",
    ".pdf": "application/pdf",
}


def _validate_file_size(size: int, filename: str):
    """Raise HTTPException if file too large."""
    max_bytes = settings.max_file_size_mb * 1024 * 1024
    if size > max_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"File '{filename}' exceeds maximum size of {settings.max_file_size_mb}MB",
        )


def _validate_extension(filename: str) -> str:
    """Validate and return the file extension. Raises HTTPException if unsupported."""
    ext = Path(filename).suffix.lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Unsupported file format: '{ext}'. "
                f"Supported formats: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
            ),
        )
    return ext


@router.post("/translate")
async def translate_file(
    file: UploadFile = File(...),
    target_lang: str = Form(...),
    source_lang: str = Form("auto"),
):
    """
    Upload a file directly for translation.

    Returns an SSE stream with progress events.
    """
    # Validate extension
    filename = file.filename or "unknown"
    _validate_extension(filename)

    # Read file bytes
    file_bytes = await file.read()

    # Validate size
    _validate_file_size(len(file_bytes), filename)

    # Generate job ID
    job_id = str(uuid.uuid4())
    job_manager.create_job(filename)

    logger.info(
        "Translation request: file=%s, target=%s, source=%s, job=%s",
        filename, target_lang, source_lang, job_id,
    )

    # Return SSE stream
    return StreamingResponse(
        orchestrator.translate_file_stream(
            job_id=job_id,
            input_bytes=file_bytes,
            filename=filename,
            target_lang=target_lang,
            source_lang=source_lang,
        ),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/translate/s3")
async def translate_s3_file(request: S3TranslateRequest):
    """
    Translate a file from S3.

    The s3_key can be an object key or full S3 URL.
    Returns an SSE stream with progress events.
    Final event includes s3_key if upload-back is enabled.
    """
    # Parse the S3 key
    s3_key = s3_client.parse_s3_url(request.s3_key)
    if not s3_key:
        raise HTTPException(
            status_code=400,
            detail="Invalid or empty S3 key/URL",
        )

    # Download from S3
    try:
        file_bytes, filename = await s3_client.download(s3_key)
    except FileNotFoundError:
        raise HTTPException(
            status_code=404,
            detail=f"S3 object not found: {s3_key}",
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to download from S3: {str(e)}",
        )

    # Validate
    _validate_extension(filename)
    _validate_file_size(len(file_bytes), filename)

    # Generate job ID
    job_id = str(uuid.uuid4())

    logger.info(
        "S3 translation request: key=%s, target=%s, source=%s, job=%s",
        s3_key, request.target_lang, request.source_lang, job_id,
    )

    async def s3_stream():
        """Wrap orchestrator stream to add S3 upload at the end."""
        import json

        async for event_str in orchestrator.translate_file_stream(
            job_id=job_id,
            input_bytes=file_bytes,
            filename=filename,
            target_lang=request.target_lang,
            source_lang=request.source_lang,
        ):
            # Check if this is the final "done" event
            if event_str.startswith("data: "):
                try:
                    event_data = json.loads(event_str[6:].strip())
                    if event_data.get("status") == "done" and settings.s3_upload_translated:
                        # Upload result back to S3
                        download_url = event_data.get("download_url", "")
                        output_filename = download_url.split("/")[-1] if download_url else ""
                        output_path = Path(settings.temp_dir) / output_filename

                        if output_path.exists():
                            try:
                                result_bytes = output_path.read_bytes()
                                ext = Path(filename).suffix.lower()
                                content_type = CONTENT_TYPE_MAP.get(ext)
                                uploaded_key = await s3_client.upload(
                                    result_bytes, s3_key, content_type
                                )
                                event_data["s3_key"] = uploaded_key
                                yield f"data: {json.dumps(event_data)}\n\n"
                                continue
                            except Exception as e:
                                logger.error("S3 upload failed: %s", str(e))
                                event_data["message"] = (
                                    event_data.get("message", "") +
                                    f" (S3 upload failed: {str(e)})"
                                )
                                yield f"data: {json.dumps(event_data)}\n\n"
                                continue
                except (json.JSONDecodeError, KeyError):
                    pass

            yield event_str

    return StreamingResponse(
        s3_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/download/{filename}")
async def download_file(filename: str):
    """
    Download a translated file.

    Returns the file with correct content-type and Content-Disposition: attachment.
    Returns 404 if the file has expired or doesn't exist.
    """
    # Sanitize filename (prevent path traversal)
    safe_filename = Path(filename).name
    file_path = Path(settings.temp_dir) / safe_filename

    if not file_path.exists() or not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="File not found. It may have expired.",
        )

    ext = file_path.suffix.lower()
    content_type = CONTENT_TYPE_MAP.get(ext, "application/octet-stream")

    return FileResponse(
        path=str(file_path),
        media_type=content_type,
        filename=safe_filename,
        headers={
            "Content-Disposition": f'attachment; filename="{safe_filename}"',
        },
    )


@router.get("/supported-formats")
async def supported_formats():
    """List supported file formats."""
    return sorted(SUPPORTED_EXTENSIONS)

"""
Single batch translation.

Takes a list of strings, sends to LLM as numbered JSON, parses response.
Implements retry + split strategy for resilience.
"""

import json
import logging

from config import settings
from app.engine.llm_client import llm_client
from app.utils.json_parser import parse_json_response

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = (
    "You are a professional translator. You translate text while preserving "
    "meaning, tone, and any technical terms. Reply ONLY with a valid JSON object. "
    "No markdown fences, no explanations, no notes."
)


def _build_user_prompt(
    numbered_texts: dict[str, str],
    target_lang: str,
    source_lang: str,
) -> str:
    """Build the user prompt with the numbered texts."""
    source_part = source_lang if source_lang != "auto" else "the source language"
    json_payload = json.dumps(numbered_texts, ensure_ascii=False)
    return (
        f"Translate every value from {source_part} to {target_lang}. "
        f"Return a JSON object with the same numeric keys. "
        f"Do NOT translate proper nouns, brand names, or code. "
        f"Do NOT add or remove keys.\n\n"
        f"{json_payload}"
    )


def _validate_response(
    parsed: dict,
    expected_keys: list[str],
) -> bool:
    """
    Validate the parsed JSON response.
    - Must be a dict
    - At least 80% of expected keys present
    - All values must be strings
    """
    if not isinstance(parsed, dict):
        return False

    # Check key coverage (at least 80%)
    present_keys = set(str(k) for k in parsed.keys())
    expected_set = set(expected_keys)
    coverage = len(present_keys & expected_set) / max(len(expected_set), 1)
    if coverage < 0.8:
        return False

    # All values must be strings
    for v in parsed.values():
        if not isinstance(v, str):
            return False

    return True


async def translate_batch(
    texts: list[str],
    target_lang: str,
    source_lang: str = "auto",
    max_retries: int = None,
) -> dict[str, str]:
    """
    Translate a batch of strings via LLM.

    Returns {original_text: translated_text} for each input string.
    NEVER throws — on total failure, returns originals unchanged.

    Implements retry + split strategy:
    - Try full batch up to max_retries times
    - If batch_size > batch_min_size, split in half and recurse
    - Otherwise, translate individually
    - Individual failures return original text unchanged
    """
    if max_retries is None:
        max_retries = settings.max_retries

    if not texts:
        return {}

    # Build numbered payload
    numbered = {str(i): text for i, text in enumerate(texts)}
    expected_keys = [str(i) for i in range(len(texts))]

    # Try the full batch with retries
    for attempt in range(1, max_retries + 1):
        try:
            user_prompt = _build_user_prompt(numbered, target_lang, source_lang)
            raw_response = await llm_client.complete(SYSTEM_PROMPT, user_prompt)

            parsed = parse_json_response(raw_response)
            if parsed is None:
                logger.warning(
                    "Batch attempt %d/%d: failed to parse JSON from LLM response",
                    attempt, max_retries,
                )
                continue

            if not _validate_response(parsed, expected_keys):
                logger.warning(
                    "Batch attempt %d/%d: response validation failed "
                    "(keys: %d/%d)",
                    attempt, max_retries,
                    len(set(str(k) for k in parsed.keys()) & set(expected_keys)),
                    len(expected_keys),
                )
                continue

            # Success — map back from numbered keys to original texts
            result = {}
            for i, text in enumerate(texts):
                key = str(i)
                if key in parsed and isinstance(parsed[key], str):
                    result[text] = parsed[key]
                else:
                    result[text] = text  # fallback to original
            return result

        except Exception as e:
            logger.warning(
                "Batch attempt %d/%d failed with error: %s",
                attempt, max_retries, str(e),
            )
            continue

    # All retries failed — apply split strategy
    logger.info(
        "All %d retries failed for batch of %d strings, applying split strategy",
        max_retries, len(texts),
    )

    if len(texts) > settings.batch_min_size:
        # Split in half and recurse
        mid = len(texts) // 2
        first_half = texts[:mid]
        second_half = texts[mid:]

        logger.info("Splitting batch: %d → %d + %d", len(texts), len(first_half), len(second_half))

        results_first = await translate_batch(first_half, target_lang, source_lang, max_retries)
        results_second = await translate_batch(second_half, target_lang, source_lang, max_retries)

        merged = {}
        merged.update(results_first)
        merged.update(results_second)
        return merged
    else:
        # Translate each string individually
        logger.info("Translating %d strings individually", len(texts))
        result = {}
        for text in texts:
            try:
                individual_result = await translate_batch(
                    [text], target_lang, source_lang, max_retries=1,
                )
                result.update(individual_result)
            except Exception:
                # Ultimate fallback: return original
                result[text] = text
        return result

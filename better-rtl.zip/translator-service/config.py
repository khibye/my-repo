from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # LLM
    llm_base_url: str = "http://localhost:11434/v1"
    llm_api_key: str = "ollama"
    llm_model: str = "gemma3:27b"
    llm_temperature: float = 0.1
    llm_max_tokens: int = 4096
    llm_timeout_seconds: int = 120

    # Batching
    batch_size: int = 30
    batch_min_size: int = 5
    max_concurrent_batches: int = 5
    max_retries: int = 3

    # File limits
    max_file_size_mb: int = 100
    max_files_per_request: int = 20
    temp_dir: str = "./temp"
    temp_file_ttl_minutes: int = 30

    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 4
    sse_heartbeat_seconds: int = 10

    # LibreOffice
    libreoffice_path: str = "/usr/bin/libreoffice"

    # S3
    s3_bucket_name: str = ""
    s3_access_key_id: str = ""
    s3_secret_access_key: str = ""
    s3_region: str = "us-east-1"
    s3_endpoint_url: str = ""
    s3_upload_translated: bool = True
    s3_translated_prefix: str = "translated/"

    class Config:
        env_file = ".env"


settings = Settings()

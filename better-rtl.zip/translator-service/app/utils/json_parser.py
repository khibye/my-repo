"""
JSON response parser for LLM output.

Tries multiple strategies to extract a valid JSON dict from raw LLM output,
handling common issues like markdown fences, trailing commas, etc.
"""

import json
import re

# Pre-compiled patterns
_RE_MARKDOWN_FENCE = re.compile(r"```(?:json)?\s*\n?(.*?)\n?\s*```", re.DOTALL)
_RE_TRAILING_COMMA = re.compile(r",\s*([}\]])")


def parse_json_response(raw: str) -> dict | None:
    """
    Parse a JSON dict from raw LLM response text.

    Tries four strategies in order:
    1. Direct json.loads
    2. Strip markdown fences
    3. Extract outermost { ... } substring
    4. Fix common issues (trailing commas, etc.)

    Returns None if all strategies fail.
    """
    if not raw or not raw.strip():
        return None

    raw = raw.strip()

    # Strategy 1: Direct parse
    result = _try_parse(raw)
    if result is not None:
        return result

    # Strategy 2: Strip markdown fences
    match = _RE_MARKDOWN_FENCE.search(raw)
    if match:
        result = _try_parse(match.group(1).strip())
        if result is not None:
            return result

    # Strategy 3: Extract outermost { ... }
    extracted = _extract_outermost_braces(raw)
    if extracted:
        result = _try_parse(extracted)
        if result is not None:
            return result

    # Strategy 4: Fix common issues and retry
    fixed = _fix_common_issues(raw)
    result = _try_parse(fixed)
    if result is not None:
        return result

    # Try fixing the extracted version too
    if extracted:
        fixed = _fix_common_issues(extracted)
        result = _try_parse(fixed)
        if result is not None:
            return result

    return None


def _try_parse(text: str) -> dict | None:
    """Attempt json.loads, return dict or None."""
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except (json.JSONDecodeError, ValueError):
        pass
    return None


def _extract_outermost_braces(text: str) -> str | None:
    """Find the outermost { ... } in the text."""
    start = text.find("{")
    if start == -1:
        return None

    depth = 0
    in_string = False
    escape_next = False

    for i in range(start, len(text)):
        ch = text[i]

        if escape_next:
            escape_next = False
            continue

        if ch == "\\":
            escape_next = True
            continue

        if ch == '"':
            in_string = not in_string
            continue

        if in_string:
            continue

        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start : i + 1]

    return None


def _fix_common_issues(text: str) -> str:
    """Fix trailing commas and other common JSON issues."""
    # Remove trailing commas before } or ]
    text = _RE_TRAILING_COMMA.sub(r"\1", text)

    # Replace single quotes with double quotes (crude but helps sometimes)
    # Only if there are no double quotes already
    if '"' not in text and "'" in text:
        text = text.replace("'", '"')

    return text

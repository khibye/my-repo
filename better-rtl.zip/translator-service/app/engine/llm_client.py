"""
Async LLM wrapper.

Wraps any OpenAI-compatible API (OpenAI, Ollama, vLLM, Together, Groq, etc.)
using the openai library's async client.
"""

import logging

from openai import AsyncOpenAI

from config import settings

logger = logging.getLogger(__name__)


class LLMClient:
    def __init__(self):
        self.client = AsyncOpenAI(
            base_url=settings.llm_base_url,
            api_key=settings.llm_api_key,
            timeout=settings.llm_timeout_seconds,
        )

    async def complete(self, system_prompt: str, user_prompt: str) -> str:
        """
        Send a chat completion request.

        Returns the raw response text.
        Raises on timeout or API error — caller handles retries.
        """
        resp = await self.client.chat.completions.create(
            model=settings.llm_model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=settings.llm_temperature,
            max_tokens=settings.llm_max_tokens,
        )
        return resp.choices[0].message.content.strip()

    async def validate_connection(self) -> bool:
        """
        Test LLM connectivity with a tiny prompt.
        Returns True if successful, False otherwise.
        """
        try:
            result = await self.complete(
                "Reply with OK.",
                "Test",
            )
            logger.info("LLM connection validated: %s", result[:50])
            return True
        except Exception as e:
            logger.warning("LLM connection failed: %s", str(e))
            return False


# Module-level singleton
llm_client = LLMClient()

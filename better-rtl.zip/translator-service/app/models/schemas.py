"""
Pydantic models for API contracts.
"""

from pydantic import BaseModel


class TranslateRequest(BaseModel):
    target_lang: str
    source_lang: str = "auto"


class S3TranslateRequest(TranslateRequest):
    s3_key: str  # object key or full S3 URL


class S3BatchTranslateRequest(TranslateRequest):
    s3_keys: list[str]


class ProgressEvent(BaseModel):
    status: str  # started | processing | done | error
    job_id: str | None = None
    progress: int | None = None  # 0-100
    message: str | None = None
    download_url: str | None = None
    s3_key: str | None = None  # populated when result uploaded to S3
    file_index: int | None = None
    filename: str | None = None
    total_files: int | None = None
    downloads: list[dict] | None = None

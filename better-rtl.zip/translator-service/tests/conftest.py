"""
Shared test fixtures and configuration.
"""

import os
import sys
import tempfile
from pathlib import Path

import pytest

# Add the project root to the path so imports work
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Set test environment variables before importing config
os.environ.setdefault("LLM_BASE_URL", "http://localhost:11434/v1")
os.environ.setdefault("LLM_API_KEY", "test-key")
os.environ.setdefault("LLM_MODEL", "test-model")
os.environ.setdefault("TEMP_DIR", tempfile.mkdtemp(prefix="translator_test_"))


@pytest.fixture
def temp_dir():
    """Provide a temporary directory for test files."""
    with tempfile.TemporaryDirectory(prefix="translator_test_") as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def sample_texts():
    """Provide sample texts for translation tests."""
    return [
        "Hello world",
        "This is a test document",
        "Please translate this text",
        "Total: $42.50",
        "Error occurred while processing",
    ]


@pytest.fixture
def sample_translations():
    """Provide sample translations (English → French)."""
    return {
        "Hello world": "Bonjour le monde",
        "This is a test document": "Ceci est un document de test",
        "Please translate this text": "Veuillez traduire ce texte",
        "Total: $42.50": "Total : 42,50 $",
        "Error occurred while processing": "Une erreur s'est produite lors du traitement",
    }

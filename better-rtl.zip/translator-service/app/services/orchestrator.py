"""
Orchestrator — Central coordinator.

Routers call the orchestrator, the orchestrator calls handlers and the engine.
This is an async generator that yields SSE-formatted strings.
"""

import asyncio
import json
import logging
import traceback
from pathlib import Path
from typing import AsyncGenerator

from config import settings
from app.engine.batcher import Batcher
from app.handlers.base import BaseHandler
from app.handlers.docx_handler import DocxHandler
from app.handlers.pptx_handler import PptxHandler
from app.handlers.xlsx_handler import XlsxHandler
from app.handlers.csv_handler import CsvHandler
from app.handlers.pdf_handler import PdfHandler
from app.services.file_converter import convert_legacy_format

logger = logging.getLogger(__name__)

# Handler registry
HANDLER_MAP: dict[str, type[BaseHandler]] = {
    ".docx": DocxHandler,
    ".pptx": PptxHandler,
    ".xlsx": XlsxHandler,
    ".xls": XlsxHandler,
    ".csv": CsvHandler,
    ".pdf": PdfHandler,
}

SUPPORTED_EXTENSIONS = {
    ".docx", ".doc", ".pptx", ".ppt",
    ".xlsx", ".xls", ".csv", ".pdf",
}


def _sse_event(data: dict) -> str:
    """Format a dict as an SSE event string."""
    return f"data: {json.dumps(data)}\n\n"


def _sse_keepalive() -> str:
    """SSE heartbeat/keepalive comment."""
    return ": keepalive\n\n"


async def translate_file_stream(
    job_id: str,
    input_bytes: bytes,
    filename: str,
    target_lang: str,
    source_lang: str = "auto",
) -> AsyncGenerator[str, None]:
    """
    Async generator that translates a file and yields SSE-formatted events.

    Flow:
    1. Determine file extension from filename
    2. Convert legacy formats (.doc, .ppt) if needed
    3. Look up handler
    4. Extract texts
    5. Batch translate with progress
    6. Write translated file
    7. Yield done event with download URL
    """
    try:
        # Yield started event
        yield _sse_event({
            "status": "started",
            "job_id": job_id,
            "message": f"Starting translation of {filename}",
        })

        # 1. Determine extension
        ext = Path(filename).suffix.lower()
        original_ext = ext

        if ext not in SUPPORTED_EXTENSIONS:
            yield _sse_event({
                "status": "error",
                "job_id": job_id,
                "message": f"Unsupported file format: {ext}",
            })
            return

        # 2. Convert legacy formats
        if ext in (".doc", ".ppt", ".xls"):
            yield _sse_event({
                "status": "processing",
                "job_id": job_id,
                "message": f"Converting {ext} to modern format...",
            })

            try:
                input_bytes, ext = await convert_legacy_format(input_bytes, ext)
                yield _sse_event({
                    "status": "processing",
                    "job_id": job_id,
                    "message": f"Converted to {ext} successfully",
                })
            except Exception as e:
                yield _sse_event({
                    "status": "error",
                    "job_id": job_id,
                    "message": f"Format conversion failed: {str(e)}",
                })
                return

        # 3. Look up handler
        handler_class = HANDLER_MAP.get(ext)
        if handler_class is None:
            yield _sse_event({
                "status": "error",
                "job_id": job_id,
                "message": f"No handler available for {ext}",
            })
            return

        # 4. Create handler and extract texts
        handler = handler_class(input_bytes)

        yield _sse_event({
            "status": "processing",
            "job_id": job_id,
            "message": "Extracting translatable text...",
        })

        # PDF handler needs target_lang for font selection
        if isinstance(handler, PdfHandler):
            unique_texts = handler.extract_texts(target_lang=target_lang)
        else:
            unique_texts = handler.extract_texts()

        stats = handler.stats
        yield _sse_event({
            "status": "processing",
            "job_id": job_id,
            "message": (
                f"Found {stats['unique_strings']} unique strings "
                f"across {stats['total_locations']} locations"
            ),
        })

        # Emit warnings if handler has them (e.g., xlsx charts)
        if hasattr(handler, "warnings"):
            for warning in handler.warnings:
                yield _sse_event({
                    "status": "processing",
                    "job_id": job_id,
                    "message": f"⚠️ {warning}",
                })

        # 5. Handle zero strings case
        if not unique_texts:
            output_ext = ext
            output_filename = f"{job_id}{output_ext}"
            output_path = Path(settings.temp_dir) / output_filename

            # Save unchanged file
            output_path.write_bytes(input_bytes)

            yield _sse_event({
                "status": "done",
                "job_id": job_id,
                "message": "No translatable text found. File saved unchanged.",
                "download_url": f"/api/download/{output_filename}",
                "progress": 100,
            })
            return

        # 6. Create batcher and run translation
        batcher = Batcher(unique_texts, target_lang, source_lang)
        task = asyncio.create_task(batcher.run())

        # SSE loop — drain queue with heartbeat timeout
        while True:
            try:
                event = await asyncio.wait_for(
                    batcher.progress_queue.get(),
                    timeout=settings.sse_heartbeat_seconds,
                )
            except asyncio.TimeoutError:
                yield _sse_keepalive()
                continue

            if event is None:
                # Sentinel — batcher is done
                break

            # Add job_id to the event and yield
            event["job_id"] = job_id
            yield _sse_event(event)

        # Wait for batcher task (should already be done)
        await task

        # 7. Get results and write translated file
        translations = batcher.get_results()

        output_ext = ext
        output_filename = f"{job_id}{output_ext}"
        output_path = Path(settings.temp_dir) / output_filename

        yield _sse_event({
            "status": "processing",
            "job_id": job_id,
            "message": "Writing translated file...",
            "progress": 95,
        })

        handler.write_translated(translations, output_path)

        # 8. Yield done event
        yield _sse_event({
            "status": "done",
            "job_id": job_id,
            "message": f"Translation complete! Translated {len(translations)} strings.",
            "download_url": f"/api/download/{output_filename}",
            "progress": 100,
        })

    except Exception as e:
        logger.error(
            "Translation failed for job %s: %s\n%s",
            job_id, str(e), traceback.format_exc(),
        )
        yield _sse_event({
            "status": "error",
            "job_id": job_id,
            "message": f"Translation failed: {str(e)}",
        })

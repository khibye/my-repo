"""
Utilities for handling Right-to-Left (RTL) text.

Ensures that languages like Arabic and Hebrew are correctly reshaped 
(for Arabic) and ordered (bidi) for rendering in PDFs.
"""

import arabic_reshaper
from bidi.algorithm import get_display


def handle_rtl_text(text: str, language: str) -> str:
    """
    Apply reshaping and bidi algorithm to text if the language is RTL.
    
    Args:
        text: The text to process
        language: Target language name (e.g. "Arabic", "Hebrew")
        
    Returns:
        Processed text ready for rendering.
    """
    lang_lower = language.lower().strip()
    
    # Check if language is RTL
    rtl_langs = ["arabic", "hebrew", "persian", "farsi", "urdu", "yiddish"]
    is_rtl = any(l in lang_lower for l in rtl_langs)
    
    if not is_rtl:
        return text

    # Apply bidi (always needed for RTL)
    # Note: arabic_reshaper is technically only for Arabic script languages,
    # but it doesn't hurt to try for all RTL if we're careful.
    # Hebrew doesn't need reshaping but needs bidi.
    
    if any(l in lang_lower for l in ["arabic", "persian", "farsi", "urdu"]):
        # Reshape Arabic characters (connect them)
        try:
            text = arabic_reshaper.reshape(text)
        except Exception:
            pass

    # Reorder characters for display
    try:
        text = get_display(text)
    except Exception:
        pass
        
    return text

"""
PDF file handler.

Extracts translatable text with coordinates from PDFs, then uses
a redact-and-stamp approach: white-out original text, insert translated
text on top at the same position.

Uses PyMuPDF (fitz) for all PDF operations.
"""

import logging
from io import BytesIO
from pathlib import Path

import fitz  # PyMuPDF

from app.handlers.base import BaseHandler
from app.utils.text_detection import is_translatable
from app.utils.fonts import pick_font, fit_fontsize, int_to_rgb
from app.utils.rtl import handle_rtl_text

logger = logging.getLogger(__name__)


class PdfHandler(BaseHandler):
    def __init__(self, input_bytes: bytes):
        super().__init__(input_bytes)
        self._doc: fitz.Document | None = None
        self._target_lang: str = ""

    def extract_texts(self, target_lang: str = "") -> list[str]:
        """
        Parse the PDF and extract all translatable text spans
        with their positions, sizes, colors, and formatting.

        Returns a deduplicated list of translatable strings.

        Known limitations:
        - Scanned PDFs (images of text) won't work (would need OCR)
        - Headers/footers are just regular text and get translated normally
        """
        self._target_lang = target_lang
        self._doc = fitz.open(stream=self.input_bytes, filetype="pdf")
        unique_set: set[str] = set()

        for page_idx, page in enumerate(self._doc):
            blocks = page.get_text(
                "dict", flags=fitz.TEXT_PRESERVE_WHITESPACE
            )["blocks"]

            for block in blocks:
                if block["type"] != 0:  # skip image blocks
                    continue

                for line in block["lines"]:
                    for span in line["spans"]:
                        text = span["text"].strip()
                        if is_translatable(text):
                            self._registry.append({
                                "page": page_idx,
                                "text": text,
                                "bbox": span["bbox"],   # (x0, y0, x1, y1)
                                "size": span["size"],   # font size in points
                                "color": span["color"], # int like 0x000000
                                "flags": span["flags"], # bold/italic bit flags
                            })
                            unique_set.add(text)

        self._unique_texts = list(unique_set)
        logger.info(
            "PDF: found %d unique strings across %d span locations (%d pages)",
            len(self._unique_texts), len(self._registry), len(self._doc),
        )
        return self._unique_texts

    def write_translated(
        self, translations: dict[str, str], output_path: Path
    ) -> None:
        """
        Write translations back to the PDF using three-step process per page:

        1. Add redaction annotations (white rectangles over original text)
        2. Apply all redactions (whites out text without touching images)
        3. Insert translated text at the same positions

        Automatically shrinks font size if translated text is longer than
        the original bounding box.
        """
        if self._doc is None:
            raise RuntimeError(
                "extract_texts() must be called before write_translated()"
            )

        # Group registry entries by page
        pages_data: dict[int, list[dict]] = {}
        for entry in self._registry:
            page_idx = entry["page"]
            if page_idx not in pages_data:
                pages_data[page_idx] = []
            pages_data[page_idx].append(entry)

        for page_idx, entries in pages_data.items():
            page = self._doc[page_idx]

            # Step 1: Add redaction annotations for all entries on this page
            for entry in entries:
                bbox = entry["bbox"]
                rect = fitz.Rect(bbox)
                page.add_redact_annot(rect, fill=(1, 1, 1))  # white fill

            # Step 2: Apply all redactions at once (preserves images)
            page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE)

            # Step 3: Insert translated text at same positions
            for entry in entries:
                original_text = entry["text"]
                translated_text = translations.get(original_text, original_text)

                bbox = entry["bbox"]
                rect = fitz.Rect(bbox)
                original_size = entry["size"]
                color_int = entry["color"]
                flags = entry["flags"]

                # Determine font based on target language and formatting
                is_bold = bool(flags & (1 << 4))  # bit 4 = bold
                is_italic = bool(flags & (1 << 1))  # bit 1 = italic
                fontname, fontfile = pick_font(
                    self._target_lang, is_bold, is_italic
                )

                # Convert color
                color_rgb = int_to_rgb(color_int)

                # Handle RTL (reshaping and bidi)
                display_text = handle_rtl_text(translated_text, self._target_lang)

                # Fit font size to available width
                available_width = rect.width
                fitted_size = fit_fontsize(
                    display_text,
                    available_width,
                    fontname,
                    fontfile,
                    original_size,
                )

                # Determine alignment: Right for RTL languages
                align = fitz.TEXT_ALIGN_RIGHT if "arabic" in self._target_lang.lower() or "hebrew" in self._target_lang.lower() else fitz.TEXT_ALIGN_LEFT

                # Insert translated text
                try:
                    page.insert_textbox(
                        rect,
                        display_text,
                        fontsize=fitted_size,
                        fontname=fontname,
                        fontfile=fontfile,
                        color=color_rgb,
                        align=align,
                    )
                except Exception as e:
                    logger.warning(
                        "PDF: failed to insert text on page %d: %s. "
                        "Falling back to basic insertion.",
                        page_idx, str(e),
                    )
                    try:
                        # Fallback: insert without custom font
                        page.insert_textbox(
                            rect,
                            display_text,
                            fontsize=fitted_size,
                            color=color_rgb,
                            align=fitz.TEXT_ALIGN_LEFT,
                        )
                    except Exception as e2:
                        logger.error(
                            "PDF: fallback insertion also failed on page %d: %s",
                            page_idx, str(e2),
                        )

        # Save with compression
        self._doc.save(
            str(output_path),
            garbage=4,
            deflate=True,
        )
        logger.info("PDF: saved translated file to %s", output_path)

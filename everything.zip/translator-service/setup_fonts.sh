#!/bin/bash

# Script to download required Noto Sans fonts for the translation service
# This ensures support for Latin, CJK (Chinese, Japanese, Korean), and Arabic script in PDFs.

set -e

FONT_DIR="./fonts"
mkdir -p "$FONT_DIR"

# Noto Sans (Latin/etc)
echo "Downloading NotoSans-Regular.ttf..."
curl -L -o "$FONT_DIR/NotoSans-Regular.ttf" "https://github.com/googlefonts/noto-fonts/raw/main/hinted/ttf/NotoSans/NotoSans-Regular.ttf"

# Noto Sans SC (Simplified Chinese)
echo "Downloading NotoSansSC-Regular.ttf..."
curl -L -o "$FONT_DIR/NotoSansSC-Regular.ttf" "https://github.com/googlefonts/noto-cjk/raw/main/Sans/OTC/NotoSansCJKsc-Regular.otf"

# Noto Sans JP (Japanese)
echo "Downloading NotoSansJP-Regular.ttf..."
curl -L -o "$FONT_DIR/NotoSansJP-Regular.ttf" "https://github.com/googlefonts/noto-cjk/raw/main/Sans/OTC/NotoSansCJKjp-Regular.otf"

# Noto Sans KR (Korean)
echo "Downloading NotoSansKR-Regular.ttf..."
curl -L -o "$FONT_DIR/NotoSansKR-Regular.ttf" "https://github.com/googlefonts/noto-cjk/raw/main/Sans/OTC/NotoSansCJKkr-Regular.otf"

# Noto Sans Arabic
echo "Downloading NotoSansArabic-Regular.ttf..."
curl -L -o "$FONT_DIR/NotoSansArabic-Regular.ttf" "https://github.com/googlefonts/noto-fonts/raw/main/hinted/ttf/NotoSansArabic/NotoSansArabic-Regular.ttf"

echo "Fonts downloaded successfully!"

"""
Batch (multi-file) translation router.

Handles uploading multiple files for translation and S3 batch translation.
Files are processed SEQUENTIALLY to avoid overloading the LLM.
"""

import io
import json
import logging
import uuid
import zipfile
from pathlib import Path

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, StreamingResponse

from config import settings
from app.models.schemas import S3BatchTranslateRequest
from app.services import orchestrator
from app.services.s3_client import s3_client

logger = logging.getLogger(__name__)

router = APIRouter()

SUPPORTED_EXTENSIONS = {
    ".docx", ".doc", ".pptx", ".ppt",
    ".xlsx", ".xls", ".csv", ".pdf",
}

CONTENT_TYPE_MAP = {
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".doc": "application/msword",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".ppt": "application/vnd.ms-powerpoint",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".xls": "application/vnd.ms-excel",
    ".csv": "text/csv",
    ".pdf": "application/pdf",
}


@router.post("/translate/batch")
async def translate_batch(
    files: list[UploadFile] = File(...),
    target_lang: str = Form(...),
    source_lang: str = Form("auto"),
):
    """
    Upload multiple files for translation.

    Returns an SSE stream with per-file progress events.
    Files are processed SEQUENTIALLY.
    """
    # Validate file count
    if len(files) > settings.max_files_per_request:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Too many files: {len(files)}. "
                f"Maximum is {settings.max_files_per_request}."
            ),
        )

    if not files:
        raise HTTPException(status_code=400, detail="No files provided")

    # Validate all files upfront
    max_bytes = settings.max_file_size_mb * 1024 * 1024
    file_data: list[tuple[str, bytes]] = []

    for f in files:
        filename = f.filename or "unknown"
        ext = Path(filename).suffix.lower()

        if ext not in SUPPORTED_EXTENSIONS:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Unsupported format '{ext}' for file '{filename}'. "
                    f"Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
                ),
            )

        file_bytes = await f.read()
        if len(file_bytes) > max_bytes:
            raise HTTPException(
                status_code=413,
                detail=f"File '{filename}' exceeds maximum size of {settings.max_file_size_mb}MB",
            )

        file_data.append((filename, file_bytes))

    # Generate batch job ID
    job_id = str(uuid.uuid4())
    job_dir = Path(settings.temp_dir) / job_id
    job_dir.mkdir(parents=True, exist_ok=True)

    logger.info(
        "Batch translation request: %d files, target=%s, job=%s",
        len(file_data), target_lang, job_id,
    )

    async def batch_stream():
        """Process each file sequentially, forwarding progress with file_index."""
        yield f"data: {json.dumps({'status': 'started', 'job_id': job_id, 'total_files': len(file_data)})}\n\n"

        downloads = []

        for file_idx, (filename, file_bytes) in enumerate(file_data):
            # File started event
            yield f"data: {json.dumps({'status': 'file_started', 'file_index': file_idx, 'filename': filename, 'job_id': job_id})}\n\n"

            # Create per-file job ID
            file_job_id = f"{job_id}_{file_idx}"

            # Stream translation for this file
            async for event_str in orchestrator.translate_file_stream(
                job_id=file_job_id,
                input_bytes=file_bytes,
                filename=filename,
                target_lang=target_lang,
                source_lang=source_lang,
            ):
                # Add file_index to progress events
                if event_str.startswith("data: "):
                    try:
                        event_data = json.loads(event_str[6:].strip())
                        event_data["file_index"] = file_idx
                        event_data["filename"] = filename

                        if event_data.get("status") == "done":
                            download_url = event_data.get("download_url", "")
                            downloads.append({
                                "filename": filename,
                                "url": download_url,
                            })
                            yield f"data: {json.dumps({'status': 'file_done', 'file_index': file_idx, 'filename': filename, 'job_id': job_id})}\n\n"
                            continue

                        yield f"data: {json.dumps(event_data)}\n\n"
                    except (json.JSONDecodeError, KeyError):
                        yield event_str
                else:
                    yield event_str

        # All files done
        yield f"data: {json.dumps({'status': 'done', 'job_id': job_id, 'downloads': downloads, 'progress': 100})}\n\n"

    return StreamingResponse(
        batch_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/translate/batch/s3")
async def translate_batch_s3(request: S3BatchTranslateRequest):
    """
    Translate multiple S3 files.

    Downloads each file from S3, translates, optionally uploads back.
    Returns SSE stream with per-file progress.
    """
    if not request.s3_keys:
        raise HTTPException(status_code=400, detail="No S3 keys provided")

    if len(request.s3_keys) > settings.max_files_per_request:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Too many files: {len(request.s3_keys)}. "
                f"Maximum is {settings.max_files_per_request}."
            ),
        )

    job_id = str(uuid.uuid4())

    logger.info(
        "S3 batch translation request: %d files, target=%s, job=%s",
        len(request.s3_keys), request.target_lang, job_id,
    )

    async def s3_batch_stream():
        total_files = len(request.s3_keys)
        yield f"data: {json.dumps({'status': 'started', 'job_id': job_id, 'total_files': total_files})}\n\n"

        downloads = []

        for file_idx, raw_key in enumerate(request.s3_keys):
            s3_key = s3_client.parse_s3_url(raw_key)

            yield f"data: {json.dumps({'status': 'file_started', 'file_index': file_idx, 'filename': s3_key, 'job_id': job_id})}\n\n"

            # Download from S3
            try:
                file_bytes, filename = await s3_client.download(s3_key)
            except Exception as e:
                yield f"data: {json.dumps({'status': 'file_error', 'file_index': file_idx, 'filename': s3_key, 'message': str(e), 'job_id': job_id})}\n\n"
                continue

            # Validate extension
            ext = Path(filename).suffix.lower()
            if ext not in SUPPORTED_EXTENSIONS:
                yield f"data: {json.dumps({'status': 'file_error', 'file_index': file_idx, 'filename': filename, 'message': f'Unsupported format: {ext}', 'job_id': job_id})}\n\n"
                continue

            file_job_id = f"{job_id}_{file_idx}"

            async for event_str in orchestrator.translate_file_stream(
                job_id=file_job_id,
                input_bytes=file_bytes,
                filename=filename,
                target_lang=request.target_lang,
                source_lang=request.source_lang,
            ):
                if event_str.startswith("data: "):
                    try:
                        event_data = json.loads(event_str[6:].strip())
                        event_data["file_index"] = file_idx
                        event_data["filename"] = filename

                        if event_data.get("status") == "done" and settings.s3_upload_translated:
                            # Upload back to S3
                            download_url = event_data.get("download_url", "")
                            output_filename = download_url.split("/")[-1] if download_url else ""
                            output_path = Path(settings.temp_dir) / output_filename

                            if output_path.exists():
                                try:
                                    result_bytes = output_path.read_bytes()
                                    content_type = CONTENT_TYPE_MAP.get(ext)
                                    uploaded_key = await s3_client.upload(
                                        result_bytes, s3_key, content_type
                                    )
                                    event_data["s3_key"] = uploaded_key
                                except Exception as ue:
                                    logger.error("S3 upload failed for %s: %s", s3_key, str(ue))

                            downloads.append({
                                "filename": filename,
                                "url": download_url,
                                "s3_key": event_data.get("s3_key"),
                            })

                            yield f"data: {json.dumps({'status': 'file_done', 'file_index': file_idx, 'filename': filename, 'job_id': job_id})}\n\n"
                            continue

                        yield f"data: {json.dumps(event_data)}\n\n"
                    except (json.JSONDecodeError, KeyError):
                        yield event_str
                else:
                    yield event_str

        yield f"data: {json.dumps({'status': 'done', 'job_id': job_id, 'downloads': downloads, 'progress': 100})}\n\n"

    return StreamingResponse(
        s3_batch_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/download/batch/{job_id}.zip")
async def download_batch_zip(job_id: str):
    """
    Download all translated files from a batch job as a zip archive.
    """
    temp_dir = Path(settings.temp_dir)

    # Find all files for this job
    matching_files = list(temp_dir.glob(f"{job_id}_*"))
    if not matching_files:
        raise HTTPException(
            status_code=404,
            detail="No files found for this batch job. They may have expired.",
        )

    # Create zip in memory
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for file_path in matching_files:
            if file_path.is_file():
                arcname = file_path.name
                zf.write(file_path, arcname)

    zip_buffer.seek(0)
    zip_filename = f"{job_id}.zip"
    zip_path = temp_dir / zip_filename
    zip_path.write_bytes(zip_buffer.getvalue())

    return FileResponse(
        path=str(zip_path),
        media_type="application/zip",
        filename=zip_filename,
        headers={
            "Content-Disposition": f'attachment; filename="{zip_filename}"',
        },
    )

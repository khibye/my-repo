"""
File Translation Service — Entry Point

Creates the FastAPI app, registers routers, manages lifecycle.
"""

import asyncio
import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from config import settings
from app.routers import translate, batch
from app.engine.llm_client import llm_client
from app.services.s3_client import s3_client
from app.services.job_manager import job_manager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

# Background cleanup task handle
_cleanup_task: asyncio.Task | None = None


async def _cleanup_loop():
    """Background task: runs every 5 minutes, deletes expired temp files."""
    while True:
        try:
            await asyncio.sleep(300)  # 5 minutes
            await job_manager.cleanup_expired()
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.error("Cleanup task error: %s", str(e))


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifecycle: startup and shutdown tasks."""
    global _cleanup_task

    # --- Startup ---
    logger.info("=" * 60)
    logger.info("File Translation Service starting up...")
    logger.info("=" * 60)

    # 1. Create temp directory if it doesn't exist
    temp_path = Path(settings.temp_dir)
    temp_path.mkdir(parents=True, exist_ok=True)
    logger.info("Temp directory: %s", temp_path.resolve())

    # 2. Validate LLM connection
    logger.info("Validating LLM connection at %s...", settings.llm_base_url)
    llm_ok = await llm_client.validate_connection()
    if llm_ok:
        logger.info("✅ LLM connection OK (model: %s)", settings.llm_model)
    else:
        logger.warning(
            "⚠️  LLM connection FAILED — translations will fail until "
            "the LLM is available at %s", settings.llm_base_url,
        )

    # 3. Validate S3 if configured
    if settings.s3_bucket_name:
        logger.info("Validating S3 connection (bucket: %s)...", settings.s3_bucket_name)
        s3_ok = await s3_client.validate_connection()
        if s3_ok:
            logger.info("✅ S3 connection OK")
        else:
            logger.warning("⚠️  S3 connection FAILED")
    else:
        logger.info("S3 not configured — S3 endpoints will not work")

    # 4. Start background cleanup task
    _cleanup_task = asyncio.create_task(_cleanup_loop())
    logger.info("Background cleanup task started (interval: 5min, TTL: %dmin)",
                settings.temp_file_ttl_minutes)

    logger.info("=" * 60)
    logger.info("Service ready! Listening on %s:%d", settings.host, settings.port)
    logger.info("=" * 60)

    yield

    # --- Shutdown ---
    logger.info("Shutting down...")

    if _cleanup_task:
        _cleanup_task.cancel()
        try:
            await _cleanup_task
        except asyncio.CancelledError:
            pass

    logger.info("Shutdown complete.")


# Create FastAPI app
app = FastAPI(
    title="File Translation Service",
    description=(
        "Translate documents in-place. Upload a file or provide an S3 link, "
        "pick a target language, and get back the same file with all "
        "human-readable text translated. Formatting, layout, formulas, "
        "and images are preserved."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers
app.include_router(translate.router, prefix="/api", tags=["Translation"])
app.include_router(batch.router, prefix="/api", tags=["Batch Translation"])


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok", "service": "file-translation-service"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host=settings.host,
        port=settings.port,
        workers=settings.workers,
        reload=False,
    )

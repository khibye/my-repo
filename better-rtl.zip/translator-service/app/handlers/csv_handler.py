"""
CSV file handler.

Extracts translatable text from CSV files with automatic encoding
and delimiter detection. Output is always UTF-8.
"""

import csv
import io
import logging
from pathlib import Path

import chardet

from app.handlers.base import BaseHandler
from app.utils.text_detection import is_translatable

logger = logging.getLogger(__name__)


class CsvHandler(BaseHandler):
    def __init__(self, input_bytes: bytes):
        super().__init__(input_bytes)
        self._rows: list[list[str]] = []
        self._dialect = None
        self._delimiter = ","

    def extract_texts(self) -> list[str]:
        """
        Parse the CSV file and extract all translatable cell values.

        1. Detect encoding via chardet (fall back to utf-8)
        2. Detect delimiter via csv.Sniffer
        3. Parse all rows, register translatable cells

        Returns a deduplicated list of translatable strings.
        """
        # Detect encoding
        detection = chardet.detect(self.input_bytes)
        encoding = detection.get("encoding", "utf-8") or "utf-8"
        logger.info("CSV: detected encoding: %s (confidence: %.1f%%)",
                     encoding, (detection.get("confidence", 0) or 0) * 100)

        try:
            text = self.input_bytes.decode(encoding)
        except (UnicodeDecodeError, LookupError):
            logger.warning("CSV: failed to decode with %s, falling back to utf-8", encoding)
            text = self.input_bytes.decode("utf-8", errors="replace")

        # Detect delimiter
        try:
            sample = text[:8192]
            dialect = csv.Sniffer().sniff(sample)
            self._delimiter = dialect.delimiter
            self._dialect = dialect
        except csv.Error:
            logger.warning("CSV: could not detect delimiter, defaulting to comma")
            self._delimiter = ","
            self._dialect = None

        # Parse rows
        reader = csv.reader(io.StringIO(text), delimiter=self._delimiter)
        unique_set: set[str] = set()

        for row_idx, row in enumerate(reader):
            self._rows.append(list(row))
            for col_idx, cell in enumerate(row):
                cell_stripped = cell.strip()
                if cell_stripped and is_translatable(cell_stripped):
                    self._registry.append((row_idx, col_idx, cell_stripped))
                    unique_set.add(cell_stripped)

        self._unique_texts = list(unique_set)
        logger.info(
            "CSV: found %d unique strings across %d cell locations "
            "(%d rows, delimiter='%s')",
            len(self._unique_texts), len(self._registry),
            len(self._rows), self._delimiter,
        )
        return self._unique_texts

    def write_translated(
        self, translations: dict[str, str], output_path: Path
    ) -> None:
        """
        Write translations back to the CSV.

        Replaces values in self._rows, writes using the same delimiter.
        Output is always UTF-8 regardless of input encoding.
        """
        # Apply translations
        for row_idx, col_idx, original in self._registry:
            if row_idx < len(self._rows) and col_idx < len(self._rows[row_idx]):
                translated = translations.get(original, original)
                self._rows[row_idx][col_idx] = translated

        # Write output (always UTF-8)
        output = io.StringIO()
        writer = csv.writer(output, delimiter=self._delimiter, quoting=csv.QUOTE_MINIMAL)
        for row in self._rows:
            writer.writerow(row)

        output_path.write_text(output.getvalue(), encoding="utf-8")
        logger.info("CSV: saved translated file to %s", output_path)

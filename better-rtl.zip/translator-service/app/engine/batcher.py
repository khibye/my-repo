"""
Concurrent batch execution engine.

Splits all unique strings into batches, runs them concurrently
with a semaphore, reports progress via asyncio.Queue.
"""

import asyncio
import logging

from config import settings
from app.engine.translator import translate_batch

logger = logging.getLogger(__name__)


class Batcher:
    def __init__(
        self,
        texts: list[str],
        target_lang: str,
        source_lang: str = "auto",
        batch_size: int = None,
        max_concurrent: int = None,
    ):
        self.texts = texts
        self.target_lang = target_lang
        self.source_lang = source_lang
        self.batch_size = batch_size or settings.batch_size
        self.max_concurrent = max_concurrent or settings.max_concurrent_batches
        self.progress_queue: asyncio.Queue = asyncio.Queue()
        self.translations: dict[str, str] = {}

    async def run(self):
        """
        Split texts into batches, run them concurrently with a semaphore,
        and report progress via the queue.

        After all batches complete, pushes None (sentinel) to the queue.
        NEVER crashes.
        """
        try:
            # Split into batches
            batches = []
            for i in range(0, len(self.texts), self.batch_size):
                batches.append(self.texts[i : i + self.batch_size])

            total_batches = len(batches)
            if total_batches == 0:
                await self.progress_queue.put(None)
                return

            logger.info(
                "Starting translation: %d strings in %d batches "
                "(max %d concurrent)",
                len(self.texts), total_batches, self.max_concurrent,
            )

            semaphore = asyncio.Semaphore(self.max_concurrent)
            completed_count = 0

            async def process_batch(batch_idx: int, batch_texts: list[str]):
                nonlocal completed_count
                async with semaphore:
                    logger.debug(
                        "Processing batch %d/%d (%d strings)",
                        batch_idx + 1, total_batches, len(batch_texts),
                    )
                    result = await translate_batch(
                        batch_texts,
                        self.target_lang,
                        self.source_lang,
                    )
                    return batch_idx, result

            # Create tasks
            tasks = [
                asyncio.create_task(process_batch(i, batch))
                for i, batch in enumerate(batches)
            ]

            # Process as they complete (fastest first)
            for coro in asyncio.as_completed(tasks):
                batch_idx, result = await coro
                self.translations.update(result)
                completed_count += 1

                progress = int((completed_count / total_batches) * 100)
                event = {
                    "status": "processing",
                    "progress": progress,
                    "message": f"Batch {completed_count}/{total_batches}",
                }
                await self.progress_queue.put(event)

                logger.debug(
                    "Batch complete: %d/%d (%d%%), got %d translations",
                    completed_count, total_batches, progress, len(result),
                )

        except Exception as e:
            logger.error("Batcher error: %s", str(e), exc_info=True)
            await self.progress_queue.put({
                "status": "error",
                "message": f"Translation error: {str(e)}",
            })
        finally:
            # Always send sentinel
            await self.progress_queue.put(None)

    def get_results(self) -> dict[str, str]:
        """Return accumulated {original: translated} dict."""
        return self.translations

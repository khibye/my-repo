"""
Font management for PDF translation.

Provides font selection based on target language and font size fitting
to ensure translated text fits within original bounding boxes.
"""

import os
from pathlib import Path

import fitz  # PyMuPDF

# Base directory for bundled fonts
_FONTS_DIR = Path(__file__).resolve().parent.parent.parent / "fonts"

# Language → font file mapping
# These cover the most common scripts that need special font files
_LANG_FONT_MAP = {
    # CJK
    "chinese": "NotoSansSC-Regular.ttf",
    "mandarin": "NotoSansSC-Regular.ttf",
    "simplified chinese": "NotoSansSC-Regular.ttf",
    "traditional chinese": "NotoSansSC-Regular.ttf",
    "japanese": "NotoSansJP-Regular.ttf",
    "korean": "NotoSansKR-Regular.ttf",
    # Arabic script
    "arabic": "NotoSansArabic-Regular.ttf",
    "persian": "NotoSansArabic-Regular.ttf",
    "farsi": "NotoSansArabic-Regular.ttf",
    "urdu": "NotoSansArabic-Regular.ttf",
    # Hebrew
    "hebrew": "NotoSansHebrew-Regular.ttf",
}

# Default font for Latin/Cyrillic/Greek and others
_DEFAULT_FONT_FILE = "NotoSans-Regular.ttf"


def pick_font(
    target_lang: str,
    is_bold: bool = False,
    is_italic: bool = False,
) -> tuple[str, str | None]:
    """
    Choose a font that supports the target language characters.

    Args:
        target_lang: Target language name (e.g. "French", "Chinese", "Arabic")
        is_bold: Whether the original text was bold
        is_italic: Whether the original text was italic

    Returns:
        (fontname, fontfile_path_or_None)
        - fontname: name to register with PyMuPDF
        - fontfile: absolute path to .ttf file, or None for built-in fonts
    """
    lang_lower = target_lang.lower().strip()

    # Check if we have a specific font for this language
    font_filename = _LANG_FONT_MAP.get(lang_lower, None)

    if font_filename is None:
        # Check partial matches (e.g., "simplified chinese" matches "chinese")
        for key, value in _LANG_FONT_MAP.items():
            if key in lang_lower or lang_lower in key:
                font_filename = value
                break

    if font_filename is None:
        font_filename = _DEFAULT_FONT_FILE

    font_path = _FONTS_DIR / font_filename

    if font_path.exists():
        fontname = font_path.stem  # e.g. "NotoSansSC-Regular"
        return fontname, str(font_path)

    # Fallback to PyMuPDF built-in Helvetica
    if is_bold and is_italic:
        return "helv", None  # Helvetica doesn't have bold-italic built-in, use base
    elif is_bold:
        return "helv", None
    elif is_italic:
        return "helv", None
    else:
        return "helv", None


def fit_fontsize(
    text: str,
    available_width: float,
    fontname: str,
    fontfile: str | None,
    original_size: float,
    min_size: float = 5.0,
) -> float:
    """
    Shrink font size iteratively until text fits within available_width.

    Args:
        text: The translated text to fit
        available_width: Width of the bounding box in points
        fontname: Font name registered with PyMuPDF
        fontfile: Path to font file, or None for built-in
        original_size: Original font size in points
        min_size: Minimum allowed font size (default 5pt)

    Returns:
        Font size in points that allows text to fit, or min_size if it can't.
    """
    if not text or available_width <= 0:
        return original_size

    font = fitz.Font(fontname, fontfile) if fontfile else fitz.Font(fontname)

    size = original_size
    while size > min_size:
        text_width = font.text_length(text, fontsize=size)
        if text_width <= available_width:
            return size
        size -= 0.5

    return min_size


def int_to_rgb(color_int: int) -> tuple[float, float, float]:
    """
    Convert integer color (0xRRGGBB) to float tuple (r, g, b) for PyMuPDF.

    Args:
        color_int: Integer like 0x000000 (black) or 0xFF0000 (red)

    Returns:
        Tuple of (r, g, b) with values in 0.0-1.0 range
    """
    r = ((color_int >> 16) & 0xFF) / 255.0
    g = ((color_int >> 8) & 0xFF) / 255.0
    b = (color_int & 0xFF) / 255.0
    return (r, g, b)

"""
Text detection utility.

Single function is_translatable() used by EVERY handler to determine
whether a string contains human-readable text worth translating.
"""

import re

# Pre-compiled regexes for performance
_RE_PURE_NUMBERS = re.compile(r"^[\d\s.,;:+\-*/=<>%$€£¥#@&|^~`!?\(\)\[\]\{\}]+$")
_RE_DATE = re.compile(
    r"^\d{1,4}[-/\.]\d{1,2}[-/\.]\d{1,4}$"
)
_RE_TIME = re.compile(r"^\d{1,2}:\d{2}(:\d{2})?(\s*(AM|PM|am|pm))?$")
_RE_HEX_HASH = re.compile(r"^[0-9a-fA-F]{8,}$")
_RE_UUID = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)
_RE_EMAIL = re.compile(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$")
_RE_URL = re.compile(r"^(https?://|ftp://|www\.)\S+$", re.IGNORECASE)
_RE_FILE_PATH = re.compile(
    r"^(/|\\|[a-zA-Z]:\\)[\w/\\.+\- ]+$"
)
_RE_PURE_SYMBOLS = re.compile(
    r"^[\s\d\W]+$", re.UNICODE
)

# Matches any letter character from any human language
_RE_HAS_LETTERS = re.compile(r"[a-zA-Z\u00C0-\u024F"   # Latin extended
                             r"\u0400-\u04FF"             # Cyrillic
                             r"\u0600-\u06FF"             # Arabic
                             r"\u0900-\u097F"             # Devanagari
                             r"\u0E00-\u0E7F"             # Thai
                             r"\u3040-\u309F"             # Hiragana
                             r"\u30A0-\u30FF"             # Katakana
                             r"\u4E00-\u9FFF"             # CJK Unified
                             r"\uAC00-\uD7AF"             # Korean Hangul
                             r"\u0370-\u03FF"             # Greek
                             r"\u0500-\u052F"             # Cyrillic Supplement
                             r"\u0530-\u058F"             # Armenian
                             r"\u0590-\u05FF"             # Hebrew
                             r"\u1000-\u109F"             # Myanmar
                             r"\u10A0-\u10FF"             # Georgian
                             r"]")


def is_translatable(value) -> bool:
    """
    Determine whether a string contains human-readable text
    worth sending to translation.

    Returns False for:
        - None, empty, or whitespace-only strings
        - Single characters
        - Pure numbers (with symbols/punctuation)
        - Dates and times
        - Hex hashes and UUIDs
        - Pure symbols/punctuation
        - Email addresses
        - URLs
        - File paths

    Returns True for:
        - Any string containing letter characters from any
          human language, including mixed content like "Total: $42.50"
    """
    if value is None:
        return False

    if not isinstance(value, str):
        return False

    text = value.strip()

    # Empty or whitespace-only
    if not text:
        return False

    # Single character
    if len(text) <= 1:
        return False

    # Pure numbers with symbols
    if _RE_PURE_NUMBERS.match(text):
        return False

    # Date patterns
    if _RE_DATE.match(text):
        return False

    # Time patterns
    if _RE_TIME.match(text):
        return False

    # Hex hashes
    if _RE_HEX_HASH.match(text):
        return False

    # UUIDs
    if _RE_UUID.match(text):
        return False

    # Email addresses
    if _RE_EMAIL.match(text):
        return False

    # URLs
    if _RE_URL.match(text):
        return False

    # File paths
    if _RE_FILE_PATH.match(text):
        return False

    # Must contain at least one letter character from any language
    if not _RE_HAS_LETTERS.search(text):
        return False

    return True

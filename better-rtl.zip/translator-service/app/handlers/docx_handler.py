"""
DOCX file handler.

Extracts translatable text from Word documents (.docx) preserving
run-level formatting, then writes translations back per-run.

Scans four locations: body paragraphs, tables, headers/footers, and text boxes.
"""

import logging
from io import BytesIO
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn

from app.handlers.base import BaseHandler
from app.utils.text_detection import is_translatable

logger = logging.getLogger(__name__)


class DocxHandler(BaseHandler):
    def __init__(self, input_bytes: bytes):
        super().__init__(input_bytes)
        self._doc: Document | None = None

    def extract_texts(self) -> list[str]:
        """
        Parse the .docx file and extract all translatable text.

        Scans:
        1. Body paragraphs → runs
        2. Tables → rows → cells → paragraphs → runs
        3. Headers and footers (including first page variants)
        4. Text boxes / shapes (via XML)

        Returns a deduplicated list of translatable strings.
        """
        self._doc = Document(BytesIO(self.input_bytes))
        unique_set: set[str] = set()

        # 1. Body paragraphs
        for para in self._doc.paragraphs:
            self._extract_runs(para, unique_set)

        # 2. Tables
        for table in self._doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    for para in cell.paragraphs:
                        self._extract_runs(para, unique_set)

        # 3. Headers and footers
        for section in self._doc.sections:
            # Main header/footer
            for hf in [section.header, section.footer]:
                if hf and not hf.is_linked_to_previous:
                    for para in hf.paragraphs:
                        self._extract_runs(para, unique_set)

            # First page header/footer
            if section.different_first_page_header_footer:
                for hf in [section.first_page_header, section.first_page_footer]:
                    if hf and not hf.is_linked_to_previous:
                        for para in hf.paragraphs:
                            self._extract_runs(para, unique_set)

        # 4. Text boxes / shapes (embedded in XML)
        self._extract_textboxes(unique_set)

        self._unique_texts = list(unique_set)
        logger.info(
            "DOCX: found %d unique strings across %d locations",
            len(self._unique_texts), len(self._registry),
        )
        return self._unique_texts

    def _extract_runs(self, paragraph, unique_set: set[str]):
        """Extract text from runs in a paragraph."""
        for run in paragraph.runs:
            text = run.text
            if text and text.strip() and is_translatable(text.strip()):
                self._registry.append(("run", run, text))
                unique_set.add(text.strip())

    def _extract_textboxes(self, unique_set: set[str]):
        """Extract text from text boxes/shapes via XML traversal."""
        if self._doc is None:
            return

        body = self._doc.element.body
        for txbx_content in body.iter(qn("w:txbxContent")):
            for p_elem in txbx_content.iter(qn("w:p")):
                for r_elem in p_elem.iter(qn("w:r")):
                    for t_elem in r_elem.iter(qn("w:t")):
                        text = t_elem.text
                        if text and text.strip() and is_translatable(text.strip()):
                            self._registry.append(("xml_t", t_elem, text))
                            unique_set.add(text.strip())

    def write_translated(
        self, translations: dict[str, str], output_path: Path
    ) -> None:
        """
        Write translations back to the document.

        For each registry entry, replaces the text content while preserving
        all formatting (font, size, color, bold, italic) since we only
        change the text content of each run/element.
        """
        if self._doc is None:
            raise RuntimeError("extract_texts() must be called before write_translated()")

        for entry in self._registry:
            entry_type = entry[0]
            original_text = entry[2]
            translated = translations.get(original_text.strip(), original_text)

            if entry_type == "run":
                run = entry[1]
                run.text = translated
            elif entry_type == "xml_t":
                t_elem = entry[1]
                t_elem.text = translated

        self._doc.save(str(output_path))
        logger.info("DOCX: saved translated file to %s", output_path)

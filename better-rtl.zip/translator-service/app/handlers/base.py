"""
Abstract base class for file format handlers.

Each handler knows how to open one file format, extract all translatable text
with position metadata, and write translations back to those same positions.
Handlers do NOT call the LLM — they just extract and inject.
"""

from abc import ABC, abstractmethod
from pathlib import Path


class BaseHandler(ABC):
    def __init__(self, input_bytes: bytes):
        self.input_bytes = input_bytes
        self._registry: list = []  # subclass fills — list of location records
        self._unique_texts: list[str] = []  # deduplicated translatable strings

    @abstractmethod
    def extract_texts(self) -> list[str]:
        """
        Parse the file. Populate self._registry with format-specific
        location data (how to find each text again when writing back).
        Return a deduplicated list of translatable strings.
        Use utils.text_detection.is_translatable() to filter.
        """

    @abstractmethod
    def write_translated(
        self, translations: dict[str, str], output_path: Path
    ) -> None:
        """
        Take {original: translated} dict, iterate self._registry,
        replace each original with its translation, save to output_path.
        If a string has no translation in the dict, keep the original.
        """

    @property
    def stats(self) -> dict:
        return {
            "total_locations": len(self._registry),
            "unique_strings": len(self._unique_texts),
        }

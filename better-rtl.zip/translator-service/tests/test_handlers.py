"""
Tests for file format handlers.

Tests extraction and write-back for each supported format.
"""

import csv
import io
from pathlib import Path

import pytest


class TestCsvHandler:
    """Tests for the CSV handler."""

    def test_extract_texts(self, temp_dir):
        """Test CSV text extraction."""
        from app.handlers.csv_handler import CsvHandler

        csv_content = "Name,Age,City\nAlice,30,New York\nBob,25,London\n"
        handler = CsvHandler(csv_content.encode("utf-8"))
        texts = handler.extract_texts()

        assert "Name" in texts
        assert "City" in texts
        assert "Alice" in texts
        assert "New York" in texts
        assert "London" in texts
        # "30" and "25" are pure numbers — should NOT be extracted
        assert "30" not in texts
        assert "25" not in texts

    def test_write_translated(self, temp_dir):
        """Test CSV translation write-back."""
        from app.handlers.csv_handler import CsvHandler

        csv_content = "Name,City\nAlice,New York\n"
        handler = CsvHandler(csv_content.encode("utf-8"))
        handler.extract_texts()

        translations = {
            "Name": "Nom",
            "City": "Ville",
            "Alice": "Alice",  # proper noun, no change
            "New York": "New York",  # proper noun
        }

        output_path = temp_dir / "output.csv"
        handler.write_translated(translations, output_path)

        result = output_path.read_text(encoding="utf-8")
        reader = csv.reader(io.StringIO(result))
        rows = list(reader)

        assert rows[0][0] == "Nom"
        assert rows[0][1] == "Ville"

    def test_encoding_detection(self):
        """Test that non-UTF-8 encodings are detected."""
        from app.handlers.csv_handler import CsvHandler

        # Create content with Latin-1 encoding
        content = "Résumé,Café\nÉlève,Naïve\n"
        handler = CsvHandler(content.encode("latin-1"))
        texts = handler.extract_texts()

        assert "Résumé" in texts or "Café" in texts

    def test_delimiter_detection(self):
        """Test that semicolon delimiter is detected."""
        from app.handlers.csv_handler import CsvHandler

        csv_content = "Name;Age;City\nAlice;30;London\n"
        handler = CsvHandler(csv_content.encode("utf-8"))
        texts = handler.extract_texts()

        assert "Name" in texts
        assert handler._delimiter == ";"


class TestDocxHandler:
    """Basic tests for DOCX handler (requires python-docx)."""

    def test_can_instantiate(self):
        """Test that the handler can be instantiated."""
        from app.handlers.docx_handler import DocxHandler

        # Create a minimal valid docx
        from docx import Document

        doc = Document()
        doc.add_paragraph("Hello World")

        buf = io.BytesIO()
        doc.save(buf)

        handler = DocxHandler(buf.getvalue())
        texts = handler.extract_texts()
        assert "Hello World" in texts

    def test_write_translated(self, temp_dir):
        """Test DOCX translation write-back."""
        from app.handlers.docx_handler import DocxHandler
        from docx import Document

        doc = Document()
        doc.add_paragraph("Hello World")
        doc.add_paragraph("Good morning")

        buf = io.BytesIO()
        doc.save(buf)

        handler = DocxHandler(buf.getvalue())
        handler.extract_texts()

        translations = {
            "Hello World": "Bonjour le monde",
            "Good morning": "Bonjour",
        }

        output_path = temp_dir / "output.docx"
        handler.write_translated(translations, output_path)

        # Verify
        result_doc = Document(str(output_path))
        paragraphs_text = [p.text for p in result_doc.paragraphs]
        assert "Bonjour le monde" in paragraphs_text
        assert "Bonjour" in paragraphs_text


class TestXlsxHandler:
    """Basic tests for XLSX handler."""

    def test_extract_texts(self):
        """Test XLSX text extraction with filtering."""
        from app.handlers.xlsx_handler import XlsxHandler
        import openpyxl

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Sales Data"
        ws["A1"] = "Product Name"
        ws["B1"] = "Revenue"
        ws["A2"] = "Widget"
        ws["B2"] = 42.50
        ws["A3"] = "=SUM(B2:B2)"  # formula

        buf = io.BytesIO()
        wb.save(buf)

        handler = XlsxHandler(buf.getvalue())
        texts = handler.extract_texts()

        assert "Product Name" in texts
        assert "Revenue" in texts
        assert "Widget" in texts
        assert "Sales Data" in texts  # sheet name is translatable
        # Should NOT include numbers or formulas
        assert "42.5" not in texts
        assert "=SUM(B2:B2)" not in texts
